'use strict';

module.exports = require('zlib').gunzipSync;
