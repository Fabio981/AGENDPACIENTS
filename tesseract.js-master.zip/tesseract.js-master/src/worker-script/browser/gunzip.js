'use strict';

module.exports = require('zlibjs').gunzipSync;
